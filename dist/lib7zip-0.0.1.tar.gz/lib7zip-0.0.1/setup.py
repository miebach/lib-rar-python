from distutils.core import setup

setup(
  name = "lib7zip",
  version = "0.0.1",
  py_modules = ["archive", "file_helper"],
  author = "Kurt Miebach",
  author_email = "kwmiebach@gmail.com",
) 
