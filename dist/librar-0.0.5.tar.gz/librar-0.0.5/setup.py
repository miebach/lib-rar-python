#from distutils.core import setup, find_packages
from setuptools import setup, find_packages

setup(
  name = "librar",
  version = "0.0.5",
  packages=find_packages(),
  author = "Kurt Miebach",
  author_email = "kwmiebach@gmail.com",
) 
